# Estação-Ômega (Expanded)

Este repositório contém os scripts e cenas expandidas das 15 fases do jogo Estação-Ômega.

## Estrutura
- `scripts/`: Scripts GDScript para cada fase.
- `scenes/`: Cenas `.tscn` correspondentes.
- `docs/`: Documentação e notas técnicas.
